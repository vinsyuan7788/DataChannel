�޸��ļ���
org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities
org.mybatis.generator.util.GeneratorConstants
org.mybatis.generator.codegen.mybatis3.xmlmapper.elements.ResultMapWithoutBLOBsElementGenerator
#org.mybatis.generator.codegen.mybatis3.model.BaseRecordGenerator
#org.mybatis.generator.codegen.AbstractGenerator