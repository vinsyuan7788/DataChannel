package org.mybatis.generator.util;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.io.IOUtils;

public class GeneratorConstants {
	
	private static Properties prop;
	
	private GeneratorConstants(){}
	
	public static String JSONB_MAPPING;
	
	static{
		InputStream in = null;
		try{
			prop = getProperties("generator.properties");
			
			JSONB_MAPPING= prop.getProperty("JSONB_MAPPING", "");
			
		}catch(Exception e){

		}finally{
			IOUtils.closeQuietly(in);
		}
	}
	
	private static Properties getProperties(String propName) throws IOException{
		InputStream in = null;
		Properties prop = null;
		try{
			prop = new Properties();
			String propPath = GeneratorConstants.class.getResource("/").getPath() + propName;
			in = new BufferedInputStream (new FileInputStream(propPath));
			prop.load(in);
			return prop;
		}finally{
			IOUtils.closeQuietly(in);
		}
		
	}
	
}
